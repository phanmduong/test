<?php $__env->startSection('title','Add Emails'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col s12">
            <h3 class="header">Thêm emails</h3>
        </div>
    </div>
    <div class="row">
        <form class="col s12" method="post" action="<?php echo e(url('manage/store_subscriber')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <?php /*<div class="input-field col s12">*/ ?>
                <?php /*<div class="row">*/ ?>
                <?php /*<textarea id="emails" name="emails" class="materialize-textarea"></textarea>*/ ?>
                <?php /*<label for="emails">Paste nội dung có chứa emails vào đây (Các email cần được ngăn cách bởi dấu*/ ?>
                <?php /*bất kì. Ví dụ: Phẩy, Cách, Chấm ...)</label>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
                <div class="col s12">
                    <p>Paste nội dung có chứa emails vào đây (Các email cần được ngăn cách bởi dấu Phẩy hoặc dấu Cách.)</p>
                    <input id="emails" name="emails" type="hidden"required >
                    <ul id="email_tags">
                    </ul>
                </div>
            </div>
            <input type="hidden" name="list_id" value="<?php echo e($list_id); ?>"/>
            <div class="row">
                <div class="col s12">
                    <input type="submit" class="btn"/>
                </div>
            </div>
        </form>
    </div>
    <div class="row">
        <div class="col s12">
            <ul class="collapsible" data-collapsible="accordion">


                <?php if(Session::has('imported')): ?>
                    <li>
                        <div class="collapsible-header"> Đã import: <strong><?php echo e(count(Session::get('imported'))); ?></strong>
                            email
                        </div>
                        <div class="collapsible-body">
                            <p>Danh sách email đã import:</p>
                            <p>
                                <?php foreach(Session::get('imported') as $email): ?>
                                    <span><?php echo e($email); ?>, </span>
                                <?php endforeach; ?>
                            </p>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if(Session::has('duplicated')): ?>
                    <li>
                        <div class="collapsible-header"> Bị trùng:
                            <strong><?php echo e(count(Session::get('duplicated'))); ?></strong> email
                        </div>
                        <div class="collapsible-body">
                            <p>Danh sách email bị trùng:</p>
                            <p>
                                <?php foreach(Session::get('duplicated') as $email): ?>
                                    <span><?php echo e($email); ?>, </span>
                                <?php endforeach; ?>
                            </p>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#email_tags").tagit({
                singleField: true,
                singleFieldNode: $('#emails'),
                beforeTagAdded: function (event, ui) {

                    if (!ui.duringInitialization) {
                        var tagArray = ui.tagLabel.split(/[\s,]+/);
                        if (tagArray.length > 1) {
                            for (var i = 0, max = tagArray.length; i < max; i++) {
                                $("#email_tags").tagit("createTag", tagArray[i]);
                            }
                            return false;
                        }
                    }
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>