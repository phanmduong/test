<div class="row">
    <div class="col s12 m6">
        <p>Tổng số tiền đã thu <strong><?php echo e(currency_vnd_format($total_money)); ?></strong></p>
        <p>Tổng số đăng kí <strong><?php echo e($register_number); ?></strong></p>
        <p>Số học viên nộp 0 đồng <strong><?php echo e($zero_paid_num); ?></strong></p>
        <p>Số lượng học viên đã đóng tiền <strong><?php echo e($paid_number); ?></strong></p>
        <p>Số lượng học viên chưa gọi điện <strong><?php echo e($uncalled_number); ?></strong></p>
        <p>Tổng số lớp <strong><?php echo e($total_classes); ?></strong></p>
        <p>Số ngày còn lại <strong><?php echo e($remain_days); ?></strong></p>
        <p>Doanh thu chỉ tiêu <strong><?php echo e(currency_vnd_format($target_revenue)); ?></strong></p>

        <div>
            <?php echo e(currency_vnd_format($total_money)); ?>/<?php echo e(currency_vnd_format($target_revenue)); ?>

            <div class="progress" style="height: 10px">
                <div class="determinate" style="width: <?php echo e($total_money*100/$target_revenue); ?>%"></div>
            </div>
        </div>


    </div>
    <?php if(isset($campaign_paids)): ?>
        <div class="col s12 m6">
            <canvas id="campaign-chart" style="width: 100%;"></canvas>
            <p style="text-align: center"><strong>Số lượng nộp tiền theo chiến dịch</strong></p>
        </div>

        <script>
            var pieChartdata = <?php echo $campaign_paids; ?>;

            var pieChartContext = $("#campaign-chart").get(0).getContext("2d");

            var pieChart = new Chart(pieChartContext)
                .Pie(pieChartdata, {
                    animateRotate: false
                });
        </script>
    <?php endif; ?>

    <?php if(count($registers_by_date_personal_temp)>0): ?>
        <div class="col s12" style="padding-bottom: 40px">
            <div>
                <div class="progress" style="height: 10px">
                    <div class="determinate" style="width: <?php echo e($count_paid*100/$count_total); ?>%"></div>
                </div>
            </div>
            <p>
                Tỉ lệ chốt đơn: <strong><?php echo e(round($count_paid*100/$count_total)); ?> %
                    (<?php echo e($count_paid); ?>

                    /<?php echo e($count_total); ?>)</strong>
            </p>
            <p>
                Thưởng: <strong><?php echo e($bonus); ?></strong>
            </p>
            <div>
                <a class="btn" href="/manage/sale-list?gen_id=<?php echo e($gen_id); ?>&saler_id=<?php echo e($user_id); ?>">Xem danh sách</a>
            </div>
        </div>

        <h3 class="header">Số lượng đăng kí theo ngày của <?php echo e($user->name); ?></h3>
        <canvas id="date-register-personal" style="width: 100%;"></canvas>

    <?php endif; ?>

    <div class="col s12">
        <h3 class="header">Số lượng đăng kí theo ngày</h3>
        <canvas id="date-register" style="width: 100%;"></canvas>
    </div>
    <div class="col s12">
        <h3 class="header">Số lượng đăng kí theo giờ</h3>
        <canvas id="hour-register" style="width: 100%;"></canvas>
    </div>

    <div class="col s12">
        <h3 class="header">Doanh thu theo ngày</h3>
        <canvas id="date-money" style="width: 100%;"></canvas>
    </div>

    <?php if($orders_by_hour): ?>
        <div class="col s12">
            <h3 class="header">Số đơn đặt hàng sách trong vòng 28 ngày</h3>
            <canvas id="date-order" style="width: 100%;"></canvas>
        </div>
    <?php endif; ?>

    <div class="col s12">
        <h3 class="header">Danh sách lớp</h3>
        <table class="responsive-table striped">
            <thead>
            <tr>
                <th></th>
                <th>Tên</th>
                <th style="width:70px">Cơ sở</th>
                <th>Học viên đã nộp tiền</th>
                <th>Số người đăng kí</th>
                <th>Thời gian học</th>
                <th>Ngày khai giảng</th>
                <th>Trạng thái Lớp</th>
                <?php /*<th style="min-width: 170px">Kích hoạt</th>*/ ?>
            </tr>
            </thead>

            <tbody>
            <?php foreach($classes as $class): ?>
                <tr>
                    <td>
                        <img width="40" class="circle" src="<?php echo e($class->course->icon_url); ?>"/>
                    </td>
                    <td><a href="<?php echo e(url('classes/'.$class->id.'/students')); ?>"><?php echo e($class->name); ?></a></td>
                    <td><?php echo e($class->base ? $class->base->name : "Không thuộc cơ sở nào"); ?></td>
                    <td class="green-text">
                        <?php if($class->target>0): ?>
                            <?php echo e($class->registers->where('status',1)->count()); ?>/<?php echo e($class->target); ?>

                            <div class="progress">
                                <div class="determinate"
                                     style="<?php echo 'width:'.(($class->registers->where('status',1)->count()*100)/$class->target); ?>%"></div>
                            </div>
                        <?php endif; ?>

                    </td>
                    <td class="blue-text">
                        <?php if($class->regis_target>0): ?>
                            <?php echo e($class->registers->count()); ?>/<?php echo e($class->regis_target); ?>

                            <div class="progress blue lighten-4">
                                <div class="determinate blue"
                                     style="<?php echo 'width:'.(($class->registers->count()*100)/$class->regis_target); ?>%"></div>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($class->study_time); ?>

                    </td>
                    <td>
                        <?php echo e($class->datestart); ?>

                    </td>
                    <td>
                        <?php if($user->role == 2): ?>
                            <div class="switch">
                                <label>
                                    <input name="status" id="class_status<?php echo e($class->id); ?>"
                                           onclick="change_status(<?php echo e($class->id); ?>);"
                                           type="checkbox" <?php echo e(($class->status==1)?"checked":""); ?> />
                                    <span class="lever"></span>
                                </label>
                            </div>
                        <?php else: ?>
                            <?php echo e(($class->status==1)?"Mở":"Đóng"); ?>

                        <?php endif; ?>
                    </td>
                    <?php /*<td id="activate<?php echo e($class->id); ?>">*/ ?>
                        <?php /*<?php if($class->activated == 1): ?>*/ ?>
                            <?php /*<strong class="cyan-text">Đã kích hoạt</strong>*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                            <?php /*<button onclick="activate('<?php echo e($class->id); ?>')" class="waves-effect waves-light btn cyan">*/ ?>
                                <?php /*Kích*/ ?>
                                <?php /*hoạt*/ ?>
                            <?php /*</button>*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                    <?php /*</td>*/ ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script>

    function activate(id) {
        $('#activate' + id).html("<strong class='red-text'>Đang gửi mail...</strong>");
        $.post('<?php echo e(url('manage/activateclass')); ?>', {
            _token: '<?php echo e(csrf_token()); ?>',
            class_id: id
        }, function (data, status) {
            $('#activate' + id).html(data);
            $('#class_status' + id).removeAttr("checked");
        });
    }
    function change_status(id) {
        $.post("<?php echo e(url('manage/changeclassstatus')); ?>",
            {
                "class_id": id,
                '_token': '<?php echo e(csrf_token()); ?>'
            },
            function (data, status) {
                console.log(status);
            });
    }

    var ctx = $("#date-register").get(0).getContext("2d");

    var options = {
        //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
        scaleBeginAtZero: true,

        //Boolean - Whether grid lines are shown across the chart
        scaleShowGridLines: true,

        //String - Colour of the grid lines
        scaleGridLineColor: "rgba(0,0,0,.05)",

        //Number - Width of the grid lines
        scaleGridLineWidth: 1,

        //Boolean - Whether to show horizontal lines (except X axis)
        scaleShowHorizontalLines: true,

        //Boolean - Whether to show vertical lines (except Y axis)
        scaleShowVerticalLines: true,

        //Boolean - If there is a stroke on each bar
        barShowStroke: true,

        //Number - Pixel width of the bar stroke
        barStrokeWidth: 2,

        //Number - Spacing between each of the X value sets
        barValueSpacing: 5,

        //Number - Spacing between data sets within X values
        barDatasetSpacing: 1

        //String - A legend template
    };

    var data = {
        labels: JSON.parse('<?php echo $date_array; ?>'),
        datasets: [
            {
                label: "Số người đăng kí theo ngày",
                fillColor: "rgba(151,187,205,0.5)",
                strokeColor: "rgba(151,187,205,0.8)",
                highlightFill: "rgba(151,187,205,0.75)",
                highlightStroke: "rgba(151,187,205,1)",
                data: JSON.parse('<?php echo $registers_by_date; ?>')
            },
            {
                fillColor: "rgba(255,0,100,0.5)",
                strokeColor: "rgba(255,0,100,0.5)",
                highlightFill: "rgba(255,0,100,0.5)",
                highlightStroke: "rgba(255,0,100,0.5)",
                data: JSON.parse('<?php echo $paid_by_date; ?>')
            }
        ]
    };


    var hourdata = {
        labels: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
        datasets: [
            {
                label: "Số người đăng kí theo giờ",
                fillColor: "rgba(151,187,205,0.5)",
                strokeColor: "rgba(151,187,205,0.8)",
                highlightFill: "rgba(151,187,205,0.75)",
                highlightStroke: "rgba(151,187,205,1)",
                data: JSON.parse('<?php echo $registers_by_hour; ?>')
            }
        ]
    };

    var dateMoney = {
        labels: JSON.parse('<?php echo $date_array; ?>'),
        datasets: [
            {
                label: "Doanh thu theo ngày",
                fillColor: "rgba(151,187,205,0.5)",
                strokeColor: "rgba(151,187,205,0.8)",
                highlightFill: "rgba(151,187,205,0.75)",
                highlightStroke: "rgba(151,187,205,1)",
                data: JSON.parse('<?php echo $money_by_date; ?>')
            }
        ]
    };

    var ctxhour = $("#hour-register").get(0).getContext("2d");
    var ctxMoneyDate = $("#date-money").get(0).getContext("2d");


    var dateRegister = new Chart(ctx).Bar(data, options);

    var hourRegister = new Chart(ctxhour).Bar(hourdata, options);
    var dateMoneyChart = new Chart(ctxMoneyDate).Bar(dateMoney, options);
</script>
<?php if(count($registers_by_date_personal_temp)>0): ?>
    <script>
        var register_personal_data = {
            labels: JSON.parse('<?php echo $date_array; ?>'),
            datasets: [
                {
                    fillColor: "rgba(151,187,205,0.5)",
                    strokeColor: "rgba(151,187,205,0.8)",
                    highlightFill: "rgba(151,187,205,0.75)",
                    highlightStroke: "rgba(151,187,205,1)",
                    data: JSON.parse('<?php echo json_encode($registers_by_date_personal); ?>')
                },
                {
                    fillColor: "rgba(255,0,100,0.5)",
                    strokeColor: "rgba(255,0,100,0.5)",
                    highlightFill: "rgba(255,0,100,0.5)",
                    highlightStroke: "rgba(255,0,100,0.5)",
                    data: JSON.parse('<?php echo json_encode($paid_by_date_personal); ?>')
                }
            ]
        };
        if ($("#date-register-personal").get(0)) {
            var ctxPersonalRegisterData = $("#date-register-personal").get(0).getContext("2d");
            var dateRegisterPersonal = new Chart(ctxPersonalRegisterData).Bar(register_personal_data, options);
        }
    </script>
<?php endif; ?>
<?php if($orders_by_hour): ?>
    <script>
        var ctxOrderDate = $("#date-order").get(0).getContext("2d");
        var orderdata = {
            labels: JSON.parse('<?php echo $month_ago; ?>'),
            datasets: [
                {
                    label: "Số đơn đặt hàng sách trong vòng 28 ngày",
                    fillColor: "rgba(151,187,205,0.5)",
                    strokeColor: "rgba(151,187,205,0.8)",
                    highlightFill: "rgba(151,187,205,0.75)",
                    highlightStroke: "rgba(151,187,205,1)",
                    data: JSON.parse('<?php echo $orders_by_hour; ?>')
                }
            ]
        };
        var dateOrder = new Chart(ctxOrderDate).Bar(orderdata, options);
    </script>
<?php endif; ?>