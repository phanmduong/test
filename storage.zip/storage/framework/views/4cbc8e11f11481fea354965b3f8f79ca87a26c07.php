<?php $__env->startSection('title','Đăng nhập'); ?>

<?php $__env->startSection('header', 'Đăng nhập'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row center" style="margin-bottom: 0;">
            <h4>Đăng nhập</h4>
        </div>
        <div class="row">
            <div class="col s12 m6 offset-m3">
                <div class="card">
                    <?php /*<div class="col s12 center card-action card-panel red lighten-1 form-header">*/ ?>
                        <?php /*<h3 class="white-text text-uppercase">Log in</h3>*/ ?>
                    <?php /*</div>*/ ?>
                    <form method="POST" action="<?php echo e(url('/login')); ?>">
                        <div class="card-content">
                            <div class="row">
                                <?php echo csrf_field(); ?>



                                <div class="input-field col s12<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <input id="email" name="email" type="email" class="validate"
                                           value="<?php echo e(old('email')); ?>" autofocus>
                                    <label for="email">Email</label>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <input id="password" name="password" type="password" class="validate"
                                           value="<?php echo e(old('password')); ?>">
                                    <label for="password">Mật khẩu</label>
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="checkbox" id="remember" name="remember"/>
                                    <label for="remember">Ghi nhớ đăng nhập</label>
                                </div>
                            </div>
                        </div>
                        <div class="card-action">

                            <button class="btn waves-effect waves-light red accent-3" type="submit" name="action">Đăng nhập
                                <i class="material-icons right">send</i>
                            </button>
                            <?php /*                            <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>*/ ?>
                            <a class="btn btn-link" href="<?php echo e(url('/register')); ?>">Tạo tài khoản</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>