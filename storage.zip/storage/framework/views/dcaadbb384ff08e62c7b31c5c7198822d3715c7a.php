<?php $__env->startSection('title','Danh sách giữ tiền'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="header">
        Danh sách người đang giữ tiền
    </h3>
    <div class="row">
        <table class="responsive-table bordered">
            <thead>
            <tr>
                <th>Tên</th>
                <th>Email</th>
                <th>Số tiền đang giữ</th>
                <th>Thu</th>
                <th>Chi</th>
                <th>Chuyển tiền</th>
            </tr>
            </thead>

            <tbody>
            <?php foreach($staffs as $staff): ?>
                <tr>
                    <td><a href="<?php echo e(url('manage/personalspendlist?id='.$staff->id)); ?>"><?php echo e($staff->name); ?></a></td>
                    <td><?php echo e($staff->email); ?></td>
                    <td class="green-text"><?php echo e(currency_vnd_format($staff->money)); ?></td>
                    <td><?php echo e($staff->send_transactions()->where('type',1)->count()); ?></td>
                    <td><?php echo e($staff->send_transactions()->where('type',2)->count()); ?></td>
                    <td><?php echo e($staff->send_transactions()->where('type',0)->count()); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <ul class="pagination">
            <?php if($current_page != 1): ?>
                <li><a class="waves-effect" href="<?php echo e(url('manage/keepmoney/'.($current_page-1))); ?>"><i
                                class="material-icons">chevron_left</i></a></li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
            <?php endif; ?>
            <?php for($i=1;$i<=$num_pages;$i++): ?>
                <?php if($current_page == $i): ?>
                    <li class="active"><a href="#!"><?php echo e($i); ?></a></li>
                <?php else: ?>
                    <li><a class="waves-effect" href="<?php echo e(url('manage/keepmoney/'.$i)); ?>"><?php echo e($i); ?></a></li>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if($current_page != $num_pages): ?>
                <li><a class="waves-effect" href="<?php echo e(url('manage/keepmoney/'.($current_page+1))); ?>"><i
                                class="material-icons">chevron_right</i></a>
                </li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
            <?php endif; ?>
        </ul>
    </div>

    <script>
        function change_status(id) {
            $.post("<?php echo e(url('manage/changeclassstatus')); ?>",
                    {
                        "class_id": id,
                        '_token': '<?php echo e(csrf_token()); ?>'
                    },
                    function (data, status) {
                        console.log(status);
                    });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>