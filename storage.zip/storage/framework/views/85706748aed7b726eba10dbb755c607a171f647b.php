<?php $__env->startSection('title','Lớp '.$class->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h3 class="header">Lớp <?php echo e($class->name); ?></h3>
        <?php if($class->teach): ?>
            <div>Giảng viên: <strong><?php echo e($class->teach->name); ?></strong></div>
        <?php endif; ?>
        <?php if($class->assist): ?>
            <div>Trợ giảng: <strong><?php echo e($class->assist->name); ?></strong></div>
        <?php endif; ?>
        <div>Tổng số học viên đã đóng tiền: <strong><?php echo e(count($students)); ?></strong></div>
        <?php if($max_score != 0): ?>
            <div>Tổng hệ số: <strong><?php echo e($max_score); ?></strong></div>
            <div style="padding: 20px 0">
                <a href="<?php echo e(url("/compute-certificate/".$class->id)); ?>" class="btn">Tổng kết bằng</a>
            </div>
        <?php endif; ?>
        <table>
            <thead>
            <tr>
                <th>Tên</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Trường</th>
                <th>Tiền học</th>
                <th>Mã thẻ</th>
                <th>Đã nhận thẻ</th>
                <th>Bằng</th>
                <th>Số buổi đã đi</th>
                <th>Tổng hệ số</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($students as $student): ?>
                <tr>
                    <td><?php echo e($student->name); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    <td><?php echo e($student->phone); ?></td>
                    <td><?php echo e($student->university); ?></td>
                    <td><span class="cm-badge"
                              style="background-color: #c50000"><?php echo e(number_format($student->money)); ?></span></td>
                    <td><?php echo e($student->code); ?></td>
                    <td><?php echo $student->received_id_card ? "<span class='cm-badge'>Rồi</span>": '<span class="red-text">Chưa</span>'; ?></td>
                    <td><?php echo e($student->certificate); ?></td>
                    <td><?php echo e($student->total_attendances); ?></td>
                    <?php if($max_score == 0): ?>
                        <td>0</td>
                    <?php else: ?>
                        <td><?php echo e($student->score*100 / $max_score); ?>% (<?php echo e($student->score); ?>/<?php echo e($max_score); ?>)</td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>