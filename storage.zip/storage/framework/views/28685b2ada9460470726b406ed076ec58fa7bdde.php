<?php $__env->startSection('title','Danh sách học viên đã nộp tiền'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="header">
        Danh sách học viên đã nộp tiền
    </h3>
    <div class="row">
        <form method="get">
            <div class="input-field col s12 m6">
                <input id="search" name="search" placeholder="Điền email, số điện thoại, hoặc tên lớp (VD: PS 9.2)"
                       type="text" value="<?php echo e(isset($search) ? $search : ""); ?>">
                <label for="search" class="active">Tìm kiếm</label>
            </div>
            <div class="input-field col s12 m6">
                <i class="waves-effect waves-light btn waves-input-wrapper">
                    <input id="submit" type="submit" value="Tìm kiếm">
                </i>
            </div>
        </form>
    </div>
    <div class="row">
        <table class="striped responsive-table">
            <thead>
            <tr>
                <th>Học viên</th>
                <th>Số điện thoại</th>
                <th>Email</th>
                <th>Lớp</th>
                <th>Số tiền</th>
                <th>Mã học viên</th>
                <th>Coupon</th>
                <th>Thời gian nộp</th>
                <th>Người thu</th>
                <th>Ghi chú</th>
            </tr>
            </thead>

            <tbody>

            <?php if($loop > 0): ?>
                <?php for($j = 0; $j < $loop; $j++): ?>
                    <tr>
                        <td><?php echo e($student_list[$j]->username); ?></td>
                        <td><?php echo e($student_list[$j]->phone); ?></td>
                        <td><?php echo e($student_list[$j]->email); ?></td>
                        <td><?php echo e($student_list[$j]->classname); ?></td>
                        <td><?php echo e(currency_vnd_format($student_list[$j]->money)); ?></td>
                        <td><?php echo e($student_list[$j]->code); ?></td>
                        <td><?php echo e($student_list[$j]->coupon); ?></td>
                        <td>
                            <?php if(property_exists($student_list[$j], "paid_time")): ?>
                                <?php echo e($student_list[$j]->paid_time); ?>

                            <?php else: ?>
                                <span>Chưa nộp</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(App\User::find($student_list[$j]->staff_id) ? App\User::find($student_list[$j]->staff_id)->name :""); ?></td>
                        <td><?php echo e($student_list[$j]->note); ?></td>
                    </tr>
                <?php endfor; ?>
            <?php endif; ?>

            <?php /*<?php foreach($student_list as $student): ?>*/ ?>
            <?php /*<?php if(!isset ($search)): ?>*/ ?>
            <?php /*<tr>*/ ?>
            <?php /*<td><?php echo e($student->name); ?></td>*/ ?>
            <?php /*<td><?php echo e($student->email); ?></td>*/ ?>
            <?php /*<td><?php echo e($student->phone); ?></td>*/ ?>
            <?php /*<td><?php echo e($student->money); ?></td>*/ ?>
            <?php /*<td><?php echo e(format_date_full_option($student->updated_at)); ?></td>*/ ?>
            <?php /*</tr>*/ ?>
            <?php /*<?php elseif(strpos($student->user->email, $search) !== false || strpos($student->user->name, $search) !== false || strpos($student->user->phone, $search) !== false): ?>*/ ?>
            <?php /*<tr>*/ ?>
            <?php /*<td><?php echo e($student->user->name); ?></td>*/ ?>
            <?php /*<td><?php echo e($student->user->email); ?></td>*/ ?>
            <?php /*<td><?php echo e($student->user->phone); ?></td>*/ ?>
            <?php /*<td><?php echo e($student->money); ?></td>*/ ?>
            <?php /*<td><?php echo e(format_date_full_option($student->updated_at)); ?></td>*/ ?>
            <?php /*</tr>*/ ?>
            <?php /*<?php endif; ?>*/ ?>
            <?php /*<?php endforeach; ?>*/ ?>
            </tbody>
        </table>
        <ul class="pagination">
            <?php if($current_page != 1): ?>
                <li><a class="waves-effect" href="<?php echo e(url('manage/paidlist/'.($current_page-1))); ?>"><i
                                class="material-icons">chevron_left</i></a></li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
            <?php endif; ?>
            <?php for($i=1;$i<=$num_pages;$i++): ?>
                <?php if($current_page == $i): ?>
                    <li class="active"><a href="#!"><?php echo e($i); ?></a></li>
                <?php else: ?>
                    <li><a class="waves-effect" href="<?php echo e(url('manage/paidlist/'.$i)); ?>"><?php echo e($i); ?></a></li>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if($current_page != $num_pages): ?>
                <li><a class="waves-effect" href="<?php echo e(url('manage/paidlist/'.($current_page+1))); ?>"><i
                                class="material-icons">chevron_right</i></a>
                </li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>