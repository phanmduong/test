<?php $__env->startSection('title',$register->user->name." - ".$register->studyClass->name); ?>

<?php $__env->startSection('content'); ?>

    <table class="bordered">
        <tr>
            <td>Name</td>
            <td><?php echo e($register->user->name); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?php echo e($register->user->email); ?></td>
        </tr>
        <tr>
            <td>Phone</td>
            <td><?php echo e($register->user->phone); ?></td>
        </tr>
        <tr>
            <td>Class</td>
            <td><?php echo e($register->studyClass->name); ?></td>
        </tr>
        <tr>
            <td>Số học viên đã đóng tiền</td>
            <td><?php echo e($register->studyClass->registers->where('status',1)->count()); ?></td>
        </tr>
        <tr>
            <td>Số học viên đăng kí</td>
            <td><?php echo e($register->studyClass->registers->count()); ?></td>
        </tr>
        <tr>
            <td>Cơ sở</td>
            <td><?php echo e($register->studyClass->base->name); ?></td>
        </tr>
    </table>
    <div class="row" style="margin-top:40px">
        <h5>Các lớp đã đăng kí</h5>
        <table class="responsive-table striped">
            <thead>
            <tr>
                <td>Tên lớp</td>
                <td>Thời gian học</td>
                <th>Đã nộp tiền</th>
                <th>Mã học viên</th>
                <th>Số tiền</th>
                <th>Thời gian nộp</th>
                <th>Thời gian đăng kí</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($old_registers as $r): ?>
                <tr>
                    <td><?php echo e($r->studyClass->name); ?></td>
                    <td><?php echo e($r->studyClass->study_time); ?></td>
                    <td><?php echo e($r->status == 1 ? 'rồi' : 'chưa'); ?></td>
                    <td><?php echo e($r->code); ?></td>
                    <td><?php echo e($r->money); ?></td>
                    <td><?php echo e(format_date_full_option($r->paid_time)); ?></td>
                    <td><?php echo e(format_date_full_option($r->created_at)); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="row" style="margin-top:40px">
        <h5>Các lớp hiện tại</h5>
        <table class="responsive-table striped">
            <thead>
            <tr>
                <td>Tên lớp</td>
                <td>Thời gian học</td>
                <th>Học viên đã nộp tiền</th>
                <th>Học viên đăng kí</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($classes as $class): ?>
                <tr>
                    <td><?php echo e($class->name); ?></td>
                    <td><?php echo e($class->study_time); ?></td>
                    <td class="green-text">
                        <?php if($class->target>0): ?>
                            <?php echo e($class->registers->where('status',1)->count()); ?>/<?php echo e($class->target); ?>

                            <div class="progress">
                                <div class="determinate"
                                     style="<?php echo 'width:'.(($class->registers->where('status',1)->count()*100)/$class->target); ?>%"></div>
                            </div>
                        <?php endif; ?>

                    </td>
                    <td class="blue-text">
                        <?php if($class->regis_target>0): ?>
                            <?php echo e($class->registers->count()); ?>/<?php echo e($class->regis_target); ?>

                            <div class="progress blue lighten-4">
                                <div class="determinate blue"
                                     style="<?php echo 'width:'.(($class->registers->count()*100)/$class->regis_target); ?>%"></div>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td><a href="<?php echo e(url('manage/confirmchangeclass?registerId='.$register->id."&classId=".$class->id)); ?>"
                           class="btn">Đổi</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>