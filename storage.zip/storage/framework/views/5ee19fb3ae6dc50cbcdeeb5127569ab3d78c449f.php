<?php $__env->startSection('title','Tất cả lịch sử gọi'); ?>

<?php $__env->startSection('content'); ?>
    <div id="app"></div>
    <script>
        window.csrfToken = "<?php echo e(csrf_token()); ?>";
        <?php if($user_id): ?>
            window.user_id = <?php echo e($user_id); ?>;
        <?php endif; ?>
    </script>
    <script src="<?php echo e(url('/telehistory/dist/app.js?5')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>