<div>
    <?php foreach($books as $book): ?>
        <div class="row" id="book-<?php echo e($book->id); ?>" style="margin-bottom:20px;">
            <div class="col-md-1 h-center">
                <img class="shadow-image"
                     src="<?php echo e($book->avatar_url); ?>">
            </div>
            <div class="col-md-4">
                <p><b style="font-weight:600;"><?php echo e($book->name); ?></b></p>
                <p><?php echo e($book->short_description); ?></p>
            </div>
            <div class="col-md-3 h-center">
                <button onclick="removeItem(<?php echo e($book->id); ?>, <?php echo e($book->price); ?>)"
                        class="btn btn-success btn-just-icon btn-sm">
                    <i class="fa fa-minus"></i>
                </button>
                &nbsp
                <button onclick="addItem(<?php echo e($book->id); ?>,<?php echo e($book->price); ?>)"
                        class="btn btn-success btn-just-icon btn-sm"><i class="fa fa-plus"></i>
                </button>
                &nbsp
                <b style="font-weight:600;" id="good-<?php echo e($book->id); ?>-number" }> <?php echo e($book->number); ?> </b>
            </div>
            <div class="col-md-2 h-center">
                <p><?php echo e(currency_vnd_format($book->price)); ?></p>
            </div>
            <div class="col-md-2 h-center">
                <p>
                    <b style="font-weight:600;" id="book-<?php echo e($book->id); ?>-price"
                       data-price="<?php echo e($book->price * $book->number); ?>">
                        <?php echo e(currency_vnd_format($book->price * $book->number)); ?>

                    </b>
                </p>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<hr>
<div class="row">
    <div class="col-md-4">
        <h4 class="text-left"><b>Tổng</b></h4>
    </div>
    <div class="col-md-8" id="total-price" data-price="<?php echo e($total_price); ?>" }>
        <h4 class="text-right"><b><?php echo e(currency_vnd_format($total_price)); ?></b></h4>
    </div>
</div>

</div>