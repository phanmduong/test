<div class="row">
    <div class="card">
        <div class="card-content">

            <div class="row">
                <div class="col s12">
                    <ul class="collapsible" data-collapsible="accordion">
                        <li>
                            <div class="collapsible-header"><i
                                        class="material-icons">filter_drama</i><?php echo e($student->name); ?>

                                : <?php echo e($student->phone); ?></div>
                            <div class="collapsible-body">
                                <div class="row">
                                    <ul class="collection">
                                        <li class="collection-item"><?php echo e($student->name); ?></li>
                                        <li class="collection-item"><?php echo e($student->email); ?></li>
                                        <li class="collection-item"><?php echo e($student->university); ?></li>
                                        <li class="collection-item"><?php echo e($student->work); ?></li>
                                        <li class="collection-item"><?php echo e($student->address); ?></li>
                                    </ul>
                                    <?php /*<table class="responsive-table">*/ ?>
                                    <?php /*<thead>*/ ?>
                                    <?php /*<tr>*/ ?>
                                    <?php /*<th>Họ tên</th>*/ ?>
                                    <?php /*<th>Email</th>*/ ?>
                                    <?php /*<th>Trường</th>*/ ?>
                                    <?php /*<th>Nơi làm việc</th>*/ ?>
                                    <?php /*<th>Địa chỉ</th>*/ ?>
                                    <?php /*</tr>*/ ?>
                                    <?php /*</thead>*/ ?>
                                    <?php /*<tbody>*/ ?>
                                    <?php /*<tr>*/ ?>
                                    <?php /*<td><?php echo e($student->name); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($student->email); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($student->university); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($student->work); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($student->address); ?></td>*/ ?>
                                    <?php /*</tr>*/ ?>
                                    <?php /*</tbody>*/ ?>
                                    <?php /*</table>*/ ?>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="collapsible-header"><i
                                        class="material-icons">filter_drama</i>Thông tin đăng kí học
                            </div>
                            <div class="collapsible-body">
                                <div class="row">

                                    <?php foreach($student->registers as $register): ?>
                                        <div class="col m6" style="border: 1px solid #7a7a7a;">
                                            <ul class="collection">
                                                <li class="collection-item">Môn <?php echo e($register->studyClass->course->name); ?></li>
                                                <?php /*<li class="collection-item"><?php echo e($register->studyClass->course->duration); ?>*/ ?>
                                                    <?php /*buổi*/ ?>
                                                <?php /*</li>*/ ?>
                                                <?php /*<li class="collection-item"><?php echo e(currency_vnd_format($register->studyClass->course->price)); ?></li>*/ ?>
                                                <li class="collection-item">Lớp <?php echo e($register->studyClass->name); ?></li>
                                                <li class="collection-item"><?php echo e($register->studyClass->study_time); ?></li>
                                                <li class="collection-item">Ngày bắt đầu: <?php echo e($register->studyClass->study_time); ?></li>

                                                <?php /*<li class="collection-item">*/ ?>
                                                    <?php /*Giảng viên:*/ ?>
                                                    <?php /*<?php echo e($register->studyClass->teach['name'] ? $register->studyClass->teach['name'] : "Chưa có"); ?>*/ ?>
                                                <?php /*</li>*/ ?>
                                                <?php /*<li class="collection-item">*/ ?>
                                                    <?php /*Trợ giảng:*/ ?>
                                                    <?php /*<?php echo e($register->studyClass->assist['name'] ? $register->studyClass->assist['name'] : "Chưa có"); ?>*/ ?>
                                                <?php /*</li>*/ ?>
                                                <li class="collection-item"><?php echo e(format_time_to_mysql(strtotime($register->created_at))); ?></li>
                                                <li class="collection-item">
                                                    Saler: <?php echo e($register->saler ? $register->saler->name : "Không có"); ?></li>

                                            </ul>
                                        </div>
                                    <?php endforeach; ?>

                                    <?php /*<table class="responsive-table">*/ ?>
                                    <?php /*<thead>*/ ?>
                                    <?php /*<tr>*/ ?>
                                    <?php /*<th>Khoá học</th>*/ ?>
                                    <?php /*<th>Số buổi</th>*/ ?>
                                    <?php /*<th>Học phí (Chưa có chiết khấu)</th>*/ ?>
                                    <?php /*<th>Lớp</th>*/ ?>
                                    <?php /*<th>Giờ học</th>*/ ?>
                                    <?php /*<th>Giảng viên</th>*/ ?>
                                    <?php /*<th>Trợ giảng</th>*/ ?>
                                    <?php /*<th>Thời gian đăng kí</th>*/ ?>
                                    <?php /*<th>Saler</th>*/ ?>
                                    <?php /*</tr>*/ ?>
                                    <?php /*</thead>*/ ?>
                                    <?php /*<tbody>*/ ?>
                                    <?php /*<?php foreach($student->registers as $register): ?>*/ ?>
                                    <?php /*<tr>*/ ?>
                                    <?php /*<td><?php echo e($register->studyClass->course->name); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($register->studyClass->course->duration); ?></td>*/ ?>
                                    <?php /*<td><?php echo e(currency_vnd_format($register->studyClass->course->price)); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($register->studyClass->name); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($register->studyClass->study_time); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($register->studyClass->teach['name']); ?></td>*/ ?>
                                    <?php /*<td><?php echo e($register->studyClass->assist['name']); ?></td>*/ ?>
                                    <?php /*<td><?php echo e(format_date($register->created_at)); ?></td>*/ ?>
                                    <?php /*<td>*/ ?>
                                    <?php /*<?php if($register->saler): ?>*/ ?>
                                    <?php /*<?php echo e($register->saler->name); ?>*/ ?>
                                    <?php /*<?php endif; ?>*/ ?>
                                    <?php /*</td>*/ ?>
                                    <?php /*</tr>*/ ?>
                                    <?php /*<?php endforeach; ?>*/ ?>
                                    <?php /*</tbody>*/ ?>
                                    <?php /*</table>*/ ?>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="collapsible-header"><i class="material-icons">place</i>Lịch sử gọi</div>
                            <div class="collapsible-body">
                                <ul class="collection with-header">
                                    <?php foreach($student->is_called->sortByDesc('updated_at') as $item): ?>
                                        <li class="collection-item">
                                            <div><?php echo e(format_date_full_option($item->updated_at)); ?></div>
                                            <div><strong><?php echo e($item->caller->name); ?></strong>
                                                gọi <?php echo call_status($item->call_status); ?>


                                            </div>
                                            <div>Ghi chú: <?php echo e($item->note); ?></div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </li>

                    </ul>
                </div>
                <form class="input-field col s12">
                    <textarea id="note" class="materialize-textarea"></textarea>
                    <label for="note">Ghi chú</label>
                </form>
            </div>
        </div>


        <div class="card-action">
            <a class="waves-effect waves-light btn" onclick="callSuccess('<?php echo e($student->id); ?>','<?php echo e($telecall_id); ?>')">Đã nghe
                máy</a>
            <a class="red waves-effect waves-light btn " onclick="callFail('<?php echo e($student->id); ?>','<?php echo e($telecall_id); ?>')">Không
                nghe máy</a>
        </div>
    </div>
</div>