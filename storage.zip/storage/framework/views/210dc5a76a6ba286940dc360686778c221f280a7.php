<?php $__env->startSection('title','Điểm danh'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php /*<div class="row">*/ ?>
    <?php /*<h3 class="header">Thêm học viên vào lớp</h3>*/ ?>
    <?php /*<form method="post" action="<?php echo e(url('manage/changeattendance')); ?>">*/ ?>
    <?php /*<div class="input-field col s12">*/ ?>
    <?php /*<input id="search" type="text" class="validate">*/ ?>
    <?php /*<label for="search">Tên,số điện thoại hoặc Email Người nhận</label>*/ ?>
    <?php /*</div>*/ ?>
    
    <?php /*<div class="col s12">*/ ?>
    <?php /*<?php echo e(csrf_field()); ?>*/ ?>
    <?php /*<input type="hidden" name="student_id" id="student_id"/>*/ ?>
    <?php /*<input type="hidden" name="class_lesson_id" id="class_lesson_id" value='<?php echo e($classLesson->id); ?>'/>*/ ?>
    <?php /*<p>Họ tên: <span id="name" style="font-weight: bold"> </span></p>*/ ?>
    <?php /*<p>Email: <span id="email" style="font-weight: bold"> </span></p>*/ ?>
    <?php /*<p>Số điện thoại: <span id="phone" style="font-weight: bold"></span></p>*/ ?>
    <?php /*<input id="btn-add-student" type="submit" disabled class=" btn"*/ ?>
    <?php /*value="Thêm"/>*/ ?>
    <?php /*</div>*/ ?>
    
    <?php /*</form>*/ ?>
    <?php /*</div>*/ ?>
    
    <div class="row">
        <h3 class="header">Điểm danh</h3>
        <p>Khóa hiện tại: <?php echo e($current_gen->name); ?></p>
        <p>Lớp <?php echo e($classLesson->studyClass->name); ?> có <?php echo e($classLesson->attendances->count()); ?> học viên</p>
        
        <table class="responsive-table striped">
            <thead>
            <tr>
                <th>Tên học sinh</th>
                <th>Email</th>
                <th>Lớp đăng kí</th>
                <th>Thiết bị</th>
                <th>Có mặt</th>
                <?php /*<th>Bài tập</th>*/ ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach($attendances as $attendance): ?>
                <?php if($attendance != null && $attendance->register != null): ?>
                    <tr>
                        <td><?php echo e($attendance->register->user->name); ?></td>
                        <td><?php echo e($attendance->register->user->email); ?></td>
                        <td><?php echo e($attendance->register->studyClass->name); ?></td>
                        <td id="device<?php echo e($attendance->id); ?>"><?php echo e($attendance->device); ?></td>
                        <td>
                            <div class="switch">
                                <label>
                                    <input name="status" id="attend_status<?php echo e($attendance->id); ?>"
                                           onclick="change_attend_status(<?php echo e($attendance->id); ?>);"
                                           type="checkbox" <?php echo e(($attendance->status==1)?"checked":""); ?> />
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </td>
                        <?php /*<td>*/ ?>
                            <?php /*<div class="switch">*/ ?>
                                <?php /*<label>*/ ?>
                                    <?php /*<input name="status" id="hw_status<?php echo e($attendance->id); ?>"*/ ?>
                                           <?php /*onclick="change_hw_status(<?php echo e($attendance->id); ?>);"*/ ?>
                                           <?php /*type="checkbox" <?php echo e(($attendance->hw_status==1)?"checked":""); ?> />*/ ?>
                                    <?php /*<span class="lever"></span>*/ ?>
                                <?php /*</label>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</td>*/ ?>
                    </tr>
                <?php endif; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script>
        
        function change_attend_status(attendance_id) {
            $("#device"+attendance_id).html("Máy tính");
            $.post('<?php echo e(url('manage/changeattendstatus')); ?>', {
                '_token': '<?php echo e(csrf_token()); ?>',
                'attendance_id': attendance_id
            }, function (data, status) {
                $("#device"+attendance_id).html(data);
            });
        }
        <?php /*function change_hw_status(attendance_id) {*/ ?>
            <?php /*$("#device"+attendance_id).html("Máy tính");*/ ?>
            <?php /*$.post('<?php echo e(url('manage/changehwstatus')); ?>', {*/ ?>
                <?php /*'_token': '<?php echo e(csrf_token()); ?>',*/ ?>
                <?php /*'attendance_id': attendance_id*/ ?>
            <?php /*}, function (data, status) {*/ ?>
                <?php /*$("#device"+attendance_id).html(data);*/ ?>
            <?php /*});*/ ?>
        <?php /*}*/ ?>
        
        <?php /*$("#search").autocomplete({*/ ?>
        <?php /*minLength: 0,*/ ?>
        <?php /*source: '<?php echo e(url('manage/autostudent')); ?>',*/ ?>
        <?php /*focus: function (event, ui) {*/ ?>
        <?php /*$("#search").val(ui.item.name);*/ ?>
        <?php /*return false;*/ ?>
        <?php /*},*/ ?>
        <?php /*select: function (event, ui) {*/ ?>
        <?php /*$("#search").val(ui.item.name);*/ ?>
        <?php /*$("#name").html(ui.item.name);*/ ?>
        <?php /*$("#email").html(ui.item.email);*/ ?>
        <?php /*$("#phone").html(ui.item.phone);*/ ?>
        <?php /*$("#student_id").val(ui.item.id);*/ ?>
        <?php /*$("#btn-add-student").removeAttr('disabled');*/ ?>
        <?php /*}*/ ?>
        <?php /*})*/ ?>
        <?php /*.autocomplete("instance")._renderItem = function (ul, item) {*/ ?>
        <?php /*return $("<li style='border-bottom: 1px solid black'>")*/ ?>
        <?php /*.append("<a><strong style='font-weight: bold'>" + item.name + "</strong><br>" + item.email + "<br>" + item.phone + "</a>")*/ ?>
        <?php /*.appendTo(ul);*/ ?>
        <?php /*};*/ ?>
        <?php /*});*/ ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>