<?php $__env->startSection('title','Chiến dịch'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col s12">
            <h3 class="header">Chiến dịch</h3>
        </div>
        <div class="col s12">
            <a class="waves-effect waves-light btn" href="<?php echo e(url('manage/campaign/new')); ?>">Tạo chiến dịch</a>
        </div>
    </div>
    <div class="row">
        <div class="col s12">
            <table>
                <thead>
                <tr>
                    <th>Status</th>
                    <th style="width: 170px">Name</th>
                    <?php /*<th style="width: 170px">Danh sách</th>*/ ?>
                    <th>Sended/Total</th>
                    <th>Delivery/Sended</th>
                    <th>Open/Delivery</th>
                    <th>Người tạo</th>
                </tr>
                </thead>

                <tbody>
                <?php foreach($campaigns as $campaign): ?>
                    <tr>
                        <td>
                            <?php if($campaign->sended == 0): ?>
                                <p class="green-text">Chưa gửi</p>
                            <?php else: ?>
                                <p style="color: #888;">Đã gửi</p>
                            <?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(url('manage/campaign?id='.$campaign->id)); ?>"><?php echo e($campaign->name); ?></a></td>
                        <?php /*<td>*/ ?>
                        <?php /*<?php if($campaign->list_id != 0): ?>*/ ?>
                        <?php /*<a href="<?php echo e(url('manage/subscribers?list_id='.$campaign->subscribers_list->id)); ?>"><?php echo e($campaign->subscribers_list->name); ?></a>*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                        <?php /*Chưa chọn*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                        <?php /*</td>*/ ?>
                        <td>
                            <?php if($campaign->subscribers_lists->count() !=0 ): ?>
                                <?php echo e($campaign->mail_sended); ?>/<?php echo e($campaign->total); ?> (<?php echo e($campaign->mail_sended_total*100); ?>%)
                                <div class="progress">
                                    <div class="determinate" style="width: <?php echo e($campaign->mail_sended_total*100); ?>%"></div>
                                </div>
                            <?php else: ?>
                                Chưa chọn danh sách
                            <?php endif; ?>

                        </td>
                        <td>
                            <?php echo e($campaign->delivery); ?>/<?php echo e($campaign->mail_sended); ?> (<?php echo e($campaign->delivery_sended*100); ?>%)
                            <div class="progress">
                                <div class="determinate" style="width: <?php echo e($campaign->delivery_sended*100); ?>%"></div>
                            </div>
                        </td>
                        <td>
                            <?php echo e($campaign->open); ?>/<?php echo e($campaign->delivery); ?> (<?php echo e($campaign->open_delivery * 100); ?>%)
                            <div class="progress">
                                <div class="determinate" style="width: <?php echo e($campaign->open_delivery * 100); ?>%"></div>
                            </div>
                        </td>

                        <td><?php echo e($campaign->owner->name); ?></td>

                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <ul class="pagination">
            <?php if($currentPage != 1): ?>
                <li><a class="waves-effect"
                       href="<?php echo e(url('manage/campaigns?page='.($currentPage-1))); ?>"><i
                                class="material-icons">chevron_left</i></a></li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
            <?php endif; ?>
            <?php for($i=1;$i<=$lastPage;$i++): ?>
                <?php if($currentPage == $i): ?>
                    <li class="active"><a href="#!"><?php echo e($i); ?></a></li>
                <?php else: ?>
                    <li><a class="waves-effect"
                           href="<?php echo e(url('manage/campaigns?page='.$i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if($currentPage != $lastPage): ?>
                <li><a class="waves-effect"
                       href="<?php echo e(url('manage/campaigns?page='.($currentPage+1))); ?>"><i
                                class="material-icons">chevron_right</i></a>
                </li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>