<tr>
    <td><?php echo e($transaction->sender->name); ?></td>
    <td><?php echo transaction_type($transaction->type); ?></td>
    <td><?php echo e(currency_vnd_format($transaction->money)); ?></td>
    <td>
        <?php if($transaction->type == 0): ?>
            Người nhận: <strong><?php echo e($transaction->receiver->name); ?></strong>
        <?php else: ?>
            <?php echo e($transaction->note); ?>

        <?php endif; ?>
    </td>
    <td><?php echo e(format_date_full_option($transaction->created_at)); ?></td>
    <td><?php echo e(currency_vnd_format($transaction->sender_money)); ?></td>
</tr>