<!DOCTYPE html>
<html>
<head>
    <title>Xoá register</title>
</head>
<body>
<table>
    <tr>
        <td>ID</td>
        <td><?php echo e($student->id); ?></td>
    </tr>
    <tr>
        <td>Tên</td>
        <td><?php echo e($student->name); ?></td>
    </tr>
    <tr>
        <td>Lớp</td>
        <td><?php echo e($class->name); ?></td>
    </tr>
    <tr>
        <td>ID lớp</td>
        <td><?php echo e($class->id); ?></td>
    </tr>
    <tr>
        <td>Người xoá ID</td>
        <td><?php echo e($staff->id); ?></td>
    </tr>
    <tr>
        <td>Tên người xoá</td>
        <td><?php echo e($staff->name); ?></td>
    </tr>
    <tr>
        <td>Email người xoá</td>
        <td><?php echo e($staff->email); ?></td>
    </tr>
</table>
</body>
</html>

