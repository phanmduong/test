<style>
    th, td {
        height: 60px;
    }
</style>
<ul class="collapsible" data-collapsible="accordion">
    <?php foreach($students as $student): ?>
        <li>
            <div class="collapsible-header"><i class="tiny material-icons">contacts</i><?php echo e($student->name); ?>

                (<?php echo e($student->email); ?>) (<?php echo e($student->phone); ?>)
            </div>
            <div class="collapsible-body">
                <table class="responsive-table">
                    <thead>
                    <tr>
                        <th>Lớp</th>
                        <th>Thời gian đăng kí</th>
                        <th>Mã học viên</th>
                        <th>Tổng số tiền nộp</th>
                        <th>Đã nhận thẻ</th>
                        <th>Ghi chú</th>
                        <th>Ngày nộp</th>
                        <th>Nộp</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($student->registers as $register): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(url('manage/editclass/'.$register->studyClass->id)); ?>"><?php echo e($register->studyClass->name); ?>

                                    (<?php echo e($register->studyClass->course->name); ?>)</a>
                            </td>
                            <td><?php echo e(format_date($register->created_at)); ?></td>
                            <td id="<?php echo e('containcode'.$register->id); ?>">
                                <?php if(isset($register->code) && $register->code != null): ?>

                                    <div>
                                        <input disabled type="text" id="<?php echo e('code'.$register->id); ?>"
                                               value="<?php echo e($register->code); ?>">
                                    </div>

                                <?php else: ?>

                                    <div>
                                        <input type="text" id="<?php echo e('code'.$register->id); ?>"
                                               value="<?php echo e(first_part_of_code($register->studyClass->name,$waitingCode,$nextCode)); ?>">
                                    </div>

                                <?php endif; ?>

                            </td>
                            <td id="<?php echo e('containmoney'.$register->id); ?>">

                                <?php if(isset($register->status) && $register->status == 1): ?>

                                    <div>
                                        <input disabled type="text" id="<?php echo e('money'.$register->id); ?>"
                                               value="<?php echo e($register->money); ?>">
                                    </div>

                                <?php else: ?>

                                    <div>
                                        <input type="text" id="<?php echo e('money'.$register->id); ?>"
                                               value="<?php echo e($register->money); ?>">
                                    </div>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(isset($register->code) && $register->code != null): ?>

                                    <input disabled="true" checked="<?php echo e($register->received_id_card); ?>" type="checkbox"
                                           id="<?php echo e('received_id_card'.$register->id); ?>"/>
                                    <label for="<?php echo e('received_id_card'.$register->id); ?>"></label>

                                <?php else: ?>

                                    <input type="checkbox" id="<?php echo e('received_id_card'.$register->id); ?>"/>
                                    <label for="<?php echo e('received_id_card'.$register->id); ?>"></label>

                                <?php endif; ?>
                            </td>
                            <td id="<?php echo e('containnote'.$register->id); ?>">
                                <?php if(isset($register->status) && $register->status == 1): ?>

                                    <div>
                                        <input disabled type="text" id="<?php echo e('note'.$register->id); ?>"
                                               value="<?php echo e($register->note); ?>">

                                    </div>
                                <?php else: ?>

                                    <div>
                                        <input type="text" id="<?php echo e('note'.$register->id); ?>"
                                               value="<?php echo e($register->note); ?>">
                                    </div>

                                <?php endif; ?>
                            </td>
                            <td id="<?php echo e('containtime'.$register->id); ?>">
                                <?php if($register->money > 0): ?>
                                    <?php echo e(format_date_full_option($register->paid_time)); ?>

                                <?php else: ?>
                                    <strong>Chưa nộp</strong>
                                <?php endif; ?>
                            </td>
                            <td id="<?php echo e('containbutton'.$register->id); ?>">
                                <?php if(isset($register->status) && $register->status == 1): ?>
                                    <strong class="green-text">Đã nộp đủ</strong>
                                <?php else: ?>
                                    <?php if($register->studyClass->target <= $register->where('status',1)->where('class_id', $register->studyClass->id)->count()): ?>
                                        <button onclick="confirmMoney('<?php echo e($register->id); ?>',1,true,'Lớp này đã có <?php echo e($register->where('status',1)->where('class_id', $register->studyClass->id)->count()); ?>/<?php echo e($register->studyClass->target); ?> học viên! Bạn vẫn muốn thêm học sinh?')"
                                                class="collect-money waves-effect waves-light btn">Nộp
                                        </button>
                                    <?php else: ?>
                                        <button onclick="confirmMoney('<?php echo e($register->id); ?>',1,false)"
                                                class="waves-effect waves-light btn">Nộp
                                        </button>
                                    <?php endif; ?>
                                    <?php /*<button onclick="confirmMoney('<?php echo e($register->id); ?>',0)"*/ ?>
                                    <?php /*class="waves-effect waves-light btn red">chưa đủ*/ ?>
                                    <?php /*</button>*/ ?>
                                <?php endif; ?>
                                <div id="loading-text<?php echo e($register->id); ?>" style="display: none" class='green-text'>Đang
                                    lưu, xin vui lòng chờ...
                                    <div class="progress">
                                        <div class="indeterminate"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </li>
    <?php endforeach; ?>
</ul>