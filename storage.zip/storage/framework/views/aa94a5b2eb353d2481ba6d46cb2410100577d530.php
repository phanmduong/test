<?php $__env->startSection('title','Danh sách'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col s12">
            <h3 class="header">Danh sách</h3>
        </div>
        <div class="col s12">
            <a class="waves-effect waves-light btn" href="<?php echo e(url('manage/new_subscribers_list')); ?>">New</a>
        </div>
    </div>
    <?php if(count($subscribersLists) == 0): ?>
        <div class="row">
            <div class="col s12 center">
                <h4>Bạn chưa tạo danh sách nào</h4>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col s12">
                <table>
                    <thead>
                    <tr>
                        <th>Tên</th>
                        <th>Số người đăng kí</th>
                        <th>Ngày tạo</th>
                        <th>Lần sửa cuối</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php foreach($subscribersLists as $subscribersList): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(url('manage/subscribers?list_id='.$subscribersList->id)); ?>"><?php echo e($subscribersList->name); ?></a>
                            </td>
                            <td><?php echo e($subscribersList->subscribers()->count()); ?></td>
                            <td><?php echo e(format_date_full_option($subscribersList->created_at)); ?></td>
                            <td><?php echo e(format_date_full_option($subscribersList->updated_at)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <ul class="pagination">
                <?php if($currentPage != 1): ?>
                    <li><a class="waves-effect"
                           href="<?php echo e(url('manage/subscribers_list?page='.($currentPage-1))); ?>"><i
                                    class="material-icons">chevron_left</i></a></li>
                <?php else: ?>
                    <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
                <?php endif; ?>
                <?php for($i=1;$i<=$lastPage;$i++): ?>
                    <?php if($currentPage == $i): ?>
                        <li class="active"><a href="#!"><?php echo e($i); ?></a></li>
                    <?php else: ?>
                        <li><a class="waves-effect"
                               href="<?php echo e(url('manage/subscribers_list?page='.$i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if($currentPage != $lastPage): ?>
                    <li><a class="waves-effect"
                           href="<?php echo e(url('manage/subscribers_list?page='.($currentPage+1))); ?>"><i
                                    class="material-icons">chevron_right</i></a>
                    </li>
                <?php else: ?>
                    <li class="disabled"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
                <?php endif; ?>
            </ul>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>