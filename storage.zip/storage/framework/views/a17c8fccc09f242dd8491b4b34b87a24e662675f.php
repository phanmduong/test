<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="page-header page-header-small" style="background-image: url('<?php echo e($properties['cover']); ?>');">
            <div class="filter"></div>
            <div class="content-center">
                <div class="container">
                    <h1 style="font-weight:600; text-transform: uppercase"><?php echo e($properties['product_type']); ?>

                        <br>
                        <?php echo e($properties['name']); ?>

                        </br>
                    </h1>
                    <h5><?php echo e($properties['short_description']); ?></h5><br>
                    <button type="button" class="btn btn-outline-neutral btn-round">
                        <i class="fa fa-shopping-cart"></i>
                        Đặt mua ngay
                    </button>
                </div>
            </div>
        </div>
        <div class="profile-content section">
            <div class="container">
                <div class="row">
                    <div class="profile-picture">
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new img-no-padding">
                                <center><img src="<?php echo e($properties['avatar']); ?>" alt="..."></center>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row" style="background:#b9b9b9">
                    <img height="10px"/>
                </div>

            </div>
        </div>
        <div class="container" id="bookinfo" style="background: white">

            <div class="row">

                <div class="col-md-6">
                    <div>
                        <div class="description">
                            <h1 class="big-title">
                                <?php echo e($properties['title1']); ?><br>
                            </h1>
                            <br><h5><?php echo e($properties['subtitle1']); ?></h5><br>

                            <p>
                                <?php echo e($properties['content1']); ?>

                            </p>

                            <br>
                            <button type="button" class="btn btn-outline-default btn-round">
                                <i class="fa fa-shopping-cart"></i>
                                Đặt mua ngay
                            </button>
                        </div>
                        <br>
                    </div>

                </div>

                <div class="col-md-6">
                    <div class="card card-profile card-plain">
                        <img class="card-img-top" src="<?php echo e($properties['img_url1']); ?>">
                    </div>

                </div>
            </div>
        </div>




        <div class="subscribe-line subscribe-line-transparent" style="background-image: url('<?php echo e($properties['cover1']); ?>')">

            <div class="content-center">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card card-profile card-plain">
                                <img class="card-img-top" src="<?php echo e($properties['img_url2']); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div>
                                <div class="description-light">
                                    <h1 class="big-title">
                                        <?php echo e($properties['title2']); ?>

                                    </h1>
                                    <br><h5><?php echo e($properties['subtitle2']); ?></h5><br>

                                    <p><?php echo e($properties['content2']); ?></p>
                                    <br>
                                    <button type="button" class="btn btn-outline-neutral btn-round">
                                        <i class="fa fa-shopping-cart"></i>
                                        Đặt mua ngay
                                    </button>
                                </div>
                                <br>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="container" id="bookinfo1" style="background: white">
            <br><br>
            <div class="row">

                <div class="col-md-6">
                    <div>
                        <div class="description">
                            <h1 class="big-title" style="color:<?php echo e($properties['main_color']); ?>!important">
                                <?php echo e($properties['counter1']); ?>

                            </h1>

                            <p><?php echo e($properties['counter1_content']); ?></p>
                            <br>
                            <h1 class="big-title" style="color:<?php echo e($properties['main_color']); ?>!important">
                                <?php echo e($properties['counter2']); ?>

                            </h1>

                            <p><?php echo e($properties['counter2_content']); ?></p>
                            <br>
                            <h1 class="big-title" style="color:<?php echo e($properties['main_color']); ?>!important">
                                <?php echo e($properties['counter3']); ?>

                            </h1>

                            <p><?php echo e($properties['counter3_content']); ?></p>
                            <br>
                            <button type="button" class="btn btn-outline-default btn-round">
                                <i class="fa fa-shopping-cart"></i>
                                Đặt mua ngay
                            </button>
                        </div>
                        <br>
                    </div>

                </div>

                <div class="col-md-6">
                    <div class="card card-profile card-plain">
                        <img class="card-img-top" src="<?php echo e($properties['img_url3']); ?>">
                    </div>
                    <br><br>
                </div>
            </div>
        </div>


        <div class="subscribe-line subscribe-line-transparent" style="background-image: url('<?php echo e($properties['cover3']); ?>')">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-md-2 text-center">
                        <h2 class="big-title description-light">Đội ngũ tác giả</h2><br><br>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card card-profile">
                            <div class="card-block">
                                <div class="card-avatar">
                                    <a href="#avatar">
                                        <img src="<?php echo e($properties['author1_avt_url']); ?>" alt="...">
                                        <h4 class="card-title"><?php echo e($properties['author1']); ?></h4>
                                    </a>
                                </div>
                                <p class="card-description text-center">
                                    <?php echo e($properties['author1_comment']); ?>

                                </p>
                            </div>
                            <div class="card-footer text-center">
                                <a href="#pablo" class="btn btn-just-icon btn-linkedin"><i class="fa fa-linkedin"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-dribbble"><i class="fa fa-dribbble"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-instagram"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-profile">
                            <div class="card-block">
                                <div class="card-avatar">
                                    <a href="#avatar">
                                        <img src="<?php echo e($properties['author2_avt_url']); ?>" alt="...">
                                        <h4 class="card-title"><?php echo e($properties['author2']); ?></h4>
                                    </a>
                                </div>
                                <p class="card-description text-center">
                                    <?php echo e($properties['author2_comment']); ?>

                                </p>
                            </div>
                            <div class="card-footer text-center">
                                <a href="#pablo" class="btn btn-just-icon btn-linkedin"><i class="fa fa-linkedin"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-dribbble"><i class="fa fa-dribbble"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-pinterest"><i class="fa fa-pinterest"></i></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card card-profile">
                            <div class="card-block">
                                <div class="card-avatar">
                                    <a href="#avatar">
                                        <img src="<?php echo e($properties['author3_avt_url']); ?>" alt="...">
                                        <h4 class="card-title"><?php echo e($properties['author3']); ?></h4>
                                    </a>
                                </div>
                                <p class="card-description text-center">
                                    <?php echo e($properties['author3_comment']); ?>

                                </p>
                            </div>
                            <div class="card-footer text-center">
                                <a href="#pablo" class="btn btn-just-icon btn-youtube"><i class="fa fa-youtube"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-twitter"><i class="fa fa-twitter"></i></a>
                                <a href="#pablo" class="btn btn-just-icon btn-instagram"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="container" id="bookinfo2" style="background: white">
            <br><br>
            <div class="row">

                <div class="col-md-6">
                    <div>
                        <div class="description">
                            <h1 class="big-title">
                                <?php echo e($properties['title4']); ?>

                            </h1>
                            <br><h5><?php echo e($properties['subtitle4']); ?></h5><br>

                            <p><?php echo e($properties['content4']); ?></p>
                            <br>
                            <button type="button" class="btn btn-outline-default btn-round">
                                <i class="fa fa-shopping-cart"></i>
                                Đặt mua ngay
                            </button>
                        </div>
                        <br>
                    </div>

                </div>

                <div class="col-md-6">
                    <div class="card card-profile card-plain">
                        <img class="card-img-top" src="<?php echo e($properties['img_url4']); ?>">
                    </div>
                </div>
            </div>
        </div>
        <hr style="margin: 0!important;">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('graphics::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>