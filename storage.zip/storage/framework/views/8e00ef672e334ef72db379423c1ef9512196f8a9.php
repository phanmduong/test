<?php $__env->startSection('title','Danh sách chờ'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="header">
        Danh sách chờ
    </h3>
    <div class="row">
        <div class="input-field col s12 m6">
            <select id="gen-select">
                <?php foreach($gens as $gen): ?>
                    <option value="<?php echo e(url('manage/waitlist?gen_id='.$gen->id.'&base_id='.$current_base_id. "&is_paid=$is_paid")); ?>"
                            <?php echo e($gen->id == $current_gen->id?"selected":""); ?>>Khoá <?php echo e($gen->name); ?></option>
                <?php endforeach; ?>
            </select>
            <label>Khoá</label>
        </div>
        <div class="input-field col s12 m6">
            <select id="base-select">
                <?php foreach($bases as $base): ?>
                    <option value="<?php echo e(url('manage/waitlist?gen_id='.$current_gen->id.'&base_id='. $base->id. "&is_paid=$is_paid")); ?>"
                            <?php echo e($base->id == $current_base_id?"selected":""); ?>><?php echo e($base->name); ?></option>
                <?php endforeach; ?>

                <option value="<?php echo e(url('manage/waitlist?gen_id='.$current_gen->id."&base_id=&paid=$is_paid")); ?>"
                        <?php echo e(!$current_base_id?"selected":""); ?>>Toàn bộ
                </option>
            </select>
            <label>Cơ sở</label>
        </div>
        <div class="input-field col s12 m6">
            <select id="paid-select">
                <option value="<?php echo e(url('manage/waitlist?gen_id='.$current_gen->id.'&base_id='. $base->id. "&is_paid=1")); ?>"
                        <?php echo e($is_paid == 1?"selected":""); ?>>Đã đóng tiền
                </option>
                <option value="<?php echo e(url('manage/waitlist?gen_id='.$current_gen->id.'&base_id='. $current_base_id. "&is_paid=0")); ?>"
                        <?php echo e($is_paid == 0 ? "selected":""); ?>>Chưa đóng tiền
                </option>
            </select>
            <label>Trạng thái nộp tiền</label>
        </div>
        <div class="input-field col s12 m6">
            <a class="btn waves-effect"
               href="<?php echo e(url("manage/downloadwaitlist?base_id=$current_base_id&is_paid=$is_paid&gen_id=".$current_gen->id)); ?>">
                Download danh sách chờ
            </a>
        </div>
    </div>

    <?php if(\Illuminate\Support\Facades\Session::has('change_class_message')): ?>
        <div class="row">
            <div class="col s12">
                <div class="card-panel">
                    <span class="green-text darken-3"><?php echo \Illuminate\Support\Facades\Session::get('change_class_message'); ?></span>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <form>
            <input type="hidden" name="gen_id" value="<?php echo e($current_gen->id); ?>">
            <input type="hidden" name="base_id" value="<?php echo e($current_base_id); ?>">
            <input type="hidden" name="is_paid" value="<?php echo e($is_paid); ?>">
            <div class="col s12 m6">
                <input name="q" value="<?php echo e($query); ?>" type="text" placeholder="Email, Ghi chú hoặc Tên"/>
            </div>
            <div class="col s12 m4">
                <input type="submit" class="btn" value="search"/>
            </div>
        </form>
    </div>
    <div class="row">
        <p>Tổng số đăng kí: <strong><?php echo e($total); ?></strong></p>
        <table class="responsive-table striped">
            <thead>
            <tr>
                <th></th>
                <th data-field="id">Họ tên</th>
                <th data-field="name">Email</th>
                <th data-field="price">Phone</th>
                <th>Ghi chú</th>
                <?php /*<th data-field="price">Coupon</th>*/ ?>
                <th>Saler</th>
                <th>Chiến dịch</th>
                <th>Đã đóng</th>
                <th>Lớp</th>
                <th>Ngày đăng kí</th>
                <th>Huỷ</th>
            </tr>
            </thead>

            <tbody>
            <?php foreach($registers as $register): ?>
                <tr>
                    <td>
                        <a href="<?php echo e(url('manage/telesalehistory?page=1&user_id='.$register->user_id)); ?>">
                            <?php if($register->call_status == 0): ?>
                                <i style="color: #a5a5a5;" class="material-icons">phone</i>
                            <?php elseif($register->call_status == 2): ?>
                                <i style="color: #c50000;" class="material-icons">phone</i>
                            <?php else: ?>
                                <i style="color: #43a047;" class="material-icons">phone</i>
                            <?php endif; ?>
                        </a>
                    </td>
                    <td><a href="<?php echo e(url('manage/changeclass/'.$register->id)); ?>"><?php echo e($register->user->name); ?></a></td>
                    <td>
                        <a href="<?php echo e(url('manage/study-history/'.$register->user_id)); ?>">
                            <?php echo e($register->user->email); ?>

                        </a>
                    </td>
                    <td><?php echo e($register->user->phone); ?></td>
                    <td><?php echo e($register->note); ?></td>
                    <?php if($register->saler): ?>
                        <td>
                            <div style="width:120px;padding:5px 0;color:white;border-radius:3px;text-align:center;background-color:#<?php echo e($register->saler->color); ?>"><?php echo e($register->saler->name); ?></div>
                        </td>
                    <?php else: ?>
                        <td style="text-align: center">Không có</td>
                    <?php endif; ?>
                    <?php if($register->marketing_campaign): ?>
                        <td>
                            <div style="width:120px;padding:5px 0;color:white;border-radius:3px;text-align:center;background-color:#<?php echo e($register->marketing_campaign->color); ?>"><?php echo e($register->marketing_campaign->name); ?></div>
                        </td>
                    <?php else: ?>
                        <td style="text-align: center">Không có</td>
                    <?php endif; ?>
                    <?php if($register->status == 1): ?>
                        <td>
                            <div style="width:120px;padding:5px 0;color:white;border-radius:3px;text-align:center;background-color:#c50000"><?php echo e(currency_vnd_format($register->money)); ?></div>
                        </td>
                    <?php else: ?>
                        <td style="text-align: center">Chưa đóng tiền</td>
                    <?php endif; ?>

                    <td><?php echo e($register->studyClass->name); ?></td>
                    <td><?php echo e(format_date($register->created_at)); ?></td>
                    <td>
                        <a onclick="return confirm('Bạn chắc chắn huỷ đăng kí này? ');"
                           href="<?php echo e(url('manage/deleteregister/'.$register->id)); ?>"><i
                                    class="small material-icons">delete</i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <ul class="pagination">
            <?php if($current_page != 1): ?>
                <li><a class="waves-effect"
                       href="<?php echo e(url('manage/waitlist?page='.($current_page-1)."&base_id=$current_base_id&is_paid=$is_paid&gen_id=".$current_gen->id.'&q='.$query)); ?>"><i
                                class="material-icons">chevron_left</i></a></li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
            <?php endif; ?>
            <?php for($i=1;$i<=$num_pages;$i++): ?>
                <?php if($current_page == $i): ?>
                    <li class="active"><a href="#!"><?php echo e($i); ?></a></li>
                <?php else: ?>
                    <li><a class="waves-effect"
                           href="<?php echo e(url('manage/waitlist?page='.$i."&base_id=$current_base_id&is_paid=$is_paid&gen_id=".$current_gen->id.'&q='.$query)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if($current_page != $num_pages): ?>
                <li><a class="waves-effect"
                       href="<?php echo e(url('manage/waitlist?page='.($current_page+1)."&base_id=$current_base_id&is_paid=$is_paid&gen_id=".$current_gen->id.'&q='.$query)); ?>"><i
                                class="material-icons">chevron_right</i></a>
                </li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
            <?php endif; ?>
        </ul>
    </div>
    <script>

        $(document).ready(function () {
            $('select').material_select();
            $("#gen-select").change(function () {
                if ($(this).val() !== '') {
                    window.location.href = $(this).val();
                }
            });
            $("#paid-select").change(function () {
                if ($(this).val() !== '') {
                    window.location.href = $(this).val();
                }
            });
            $("#base-select").change(function () {
                if ($(this).val() !== '') {
                    window.location.href = $(this).val();
                }
            });
        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>