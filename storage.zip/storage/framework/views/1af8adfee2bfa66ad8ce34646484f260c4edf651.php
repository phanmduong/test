<table class="responsive-table striped">
    <thead>
    <tr>
        <th>Số thứ tự</th>
        <th>Tên buổi</th>
        <th>Thời gian</th>
        <th></th>
    </tr>
    </thead>

    <tbody>
    <?php foreach($lessons as $lesson): ?>
        <tr>
            <td><?php echo e($lesson->order); ?></td>
            <td><?php echo e($lesson->name); ?></td>
            <td>
                <input value="<?php echo e($lesson->pivot->time?format_date_eng($lesson->pivot->time):''); ?>"
                       id="class-lesson-time<?php echo e($lesson->id); ?>" class="datepicker" type="text"/>
            </td>
            <td>
                <button class="waves-effect waves-light btn waves-input-wrapper" onclick="save(<?php echo e($lesson->id); ?>)">Lưu
                </button>
                <span id="message<?php echo e($lesson->id); ?>"></span>
            </td>
        </tr>
    <?php endforeach; ?>


    </tbody>
</table>
<script>
    $(document).ready(function () {
        $('.datepicker').pickadate();
    });
</script>