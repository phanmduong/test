<?php $__env->startSection('title',$cam->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col s12">
            <h3 class="header"><?php echo e($cam->name); ?></h3>
        </div>
        <?php if($cam->sended == 0): ?>
            <div class="col s12">
                <a class="btn" href="<?php echo e(url('manage/campaign/edit?id='.$cam->id)); ?>">Edit</a>
            </div>
        <?php else: ?>
            <form method="post" action="<?php echo e(url('manage/sendmorelist')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="col s12">
                    <p>Thêm danh sách</p>
                    <input id="list_id" name="list_id" type="hidden">
                    <ul id="list_id_tag">
                    </ul>
                </div>
                <div class="col s12">
                    <p id="message" style="color: #c50000;"></p>
                </div>
                <input type="hidden" value="<?php echo e($cam->id); ?>" name="cam_id">
                <div class="col s12">
                    <input type="submit" class="btn teal" value="Gửi"/>
                </div>

            </form>
        <?php endif; ?>
        <div class="col s12">
            <p>Subject: <strong><?php echo e($cam->subject); ?></strong></p>
            <?php if($cam->subscribers_lists->count() !=0): ?>
                <p>Danh sách:</p>
                <p>
                <table>
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Tên</th>
                        <th>Số lượng email</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($lists as $list): ?>
                        <tr>
                            <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->name); ?></td>
                            <td><?php echo e($list->subscribers->count()); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </p>
                <p>Số lượng email: <strong><?php echo e($total); ?> emails</strong> (Đã loại những email bị trùng lặp)</p>
            <?php else: ?>
                <p>Danh sách: <strong>Chưa chọn</strong></p>
            <?php endif; ?>

            <p>Template:
                <?php if($cam->template!=null): ?>
                    <strong><?php echo e($cam->template->name); ?> (<a target="_blank"
                                                         href="<?php echo e(url('manage/template/view?id='.$cam->template->id)); ?>">view</a>)</strong>
                <?php else: ?>
                    <strong>Chưa chọn</strong>
                <?php endif; ?>
            </p>
        </div>
    </div>
    <?php if($cam->sended == 0): ?>
        <div class="row">
            <div class="col s12">
                <ul class="collapsible" data-collapsible="accordion">
                    <li>
                        <div class="collapsible-header"><i class="material-icons">file_upload</i>Upload Email File</div>
                        <div class="collapsible-body">
                            <div class="col s12">
                                <form method="post" enctype="multipart/form-data"
                                      action="<?php echo e(url('manage/campaign/store_email_template')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="id" value="<?php echo e($cam->id); ?>"/>
                                    <div class="file-field input-field">
                                        <div class="btn">
                                            <span>File</span>
                                            <input name="email_template" type="file">
                                        </div>
                                        <div class="file-path-wrapper">
                                            <input class="file-path validate" type="text">
                                        </div>
                                    </div>
                                    <input class="btn" type="submit" value="upload"/>
                                </form>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="collapsible-header"><i class="material-icons">folder</i>Chọn từ Email có sẵn</div>
                        <div class="collapsible-body">
                            <ul class="collection">
                                <?php foreach($templates as $template): ?>
                                    <?php if($template->id != $cam->template_id): ?>
                                        <li class="collection-item"><?php echo e($template->name); ?>

                                            <span class="secondary-content">
                                        <a href="<?php echo e(url('manage/template/view?id='.$template->id)); ?>"><i
                                                    class="material-icons">remove_red_eye</i></a>
                                        <a href="<?php echo e(url('manage/campaign/select_template?cam_id='.$cam->id.'&id='.$template->id)); ?>"><i
                                                    class="material-icons">forward</i></a>
                                    </span>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; ?>

                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col s12">
                <?php if($can_send): ?>
                    <a class="btn red darken-4" href="<?php echo e(url('manage/mail/queue?id='.$cam->id)); ?>">Gửi</a>
                <?php else: ?>
                    <p>Bạn cần <strong>nhập email template</strong> và chọn <strong>danh sách gửi</strong></p>
                    <a class="btn red darken-4 disabled" onclick="return false;">Gửi</a>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col s12">
                <?php /*<p>Thời gian bắt đầu gửi: <strong><?php echo e(format_date_full_option($cam->updated_at)); ?></strong></p>*/ ?>
                <p>Thời gian gửi dự kiến: <strong><?php echo e(gmdate("H:i:s", $cam->send_time)); ?></strong></p>
                <p>Thời gian bắt đầu gửi: <strong><?php echo e(format_date_full_option($cam->updated_at)); ?></strong></p>
                <p>Tổng số mail đã gửi: <strong><?php echo e($cam->emails()->count()); ?></strong></p>
                <p>Số mail đã được nhận(<?php echo e(email_status_int_to_str(1)); ?>):
                    <strong><?php echo e($delivery); ?></strong></p>
                <p>Số mail đã được mở(<?php echo e(email_status_int_to_str(3)); ?>):
                    <strong><?php echo e($open); ?></strong></p>
                <p>Số mail (<?php echo e(email_status_int_to_str(2)); ?>):
                    <strong><?php echo e($bounce); ?></strong></p>
                <p>Số mail bị phàn nàn(<?php echo e(email_status_int_to_str(4)); ?>):
                    <strong><?php echo e($complaint); ?></strong></p>
            </div>
        </div>
        <div class="row">
            <div class="col s12">
                <a disabled="" class="btn red darken-4 disabled" onclick="return false;">Đã gửi</a>
            </div>
        </div>
    <?php endif; ?>
    <script>
        $(document).ready(function () {
            var tags = <?php echo $tags; ?>;

            $("#list_id_tag").tagit({
                availableTags: tags,
                singleField: true,
                singleFieldNode: $('#list_id'),
                beforeTagAdded: function (event, ui) {
                    // do something special
                    var label = ui.tagLabel;
                    var a = tags.indexOf(label);
                    if (a === -1) {
                        $('#message').html('Danh sách bạn nhập không tồn tại. Lưu ý: bạn hãy gõ tên danh sách bắt đầu từ chữ cái đầu tiên và hệ thông sẽ gợi ý');
                        return false;
                    }
                }
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>