<?php foreach($rule_chapters as $rule_chapter): ?>
    <h4><strong>PHẦN <?php echo e($rule_chapter->order); ?>: <?php echo e($rule_chapter->name); ?></strong></h4>
    <p><?php echo e($rule_chapter->description); ?></p>
    <?php foreach($rule_chapter->rules as $rule_parent): ?>
        <h6><strong>Mục <?php echo e($rule_parent->order); ?>: <?php echo e($rule_parent->name); ?></strong></h6>
        <?php echo e($rule_parent->description); ?>

        <?php if(count($rule_parent->rule_childs) > 0): ?>
            <blockquote style="font-size:15px">
                <?php foreach($rule_parent->rule_childs as $rule_child): ?>
                    <strong>Điều <?php echo e($rule_child->order); ?>: <?php echo e($rule_child->name); ?></strong>
                    <br><?php echo e($rule_child->description); ?><br>
                    <?php if(count(($rule_child->finesRewards)) > 0): ?>
                        <blockquote style="font-size:15px">
                            <?php foreach($rule_child->finesRewards as $fineReward): ?>
                                <?php if($fineReward->kind == 1): ?>
                                    <strong style="color:#c50000">Hình thức xử lý: </strong><?php echo e($fineReward->description); ?>

                                    <br/>
                                <?php else: ?>
                                    <strong style="color:#00c505">Thưởng: </strong><?php echo e($fineReward->description); ?><br/>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </blockquote>
                    <?php endif; ?>
                <?php endforeach; ?>
            </blockquote>
        <?php endif; ?>
    <?php endforeach; ?>
    <br/>
    <br/>
<?php endforeach; ?>


