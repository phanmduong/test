<?php $__env->startSection('title','Danh sách đăng kí học'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="header">
        <?php echo e(($isEdit)?"Sửa":"Thêm mới"); ?> lớp học
    </h3>
    <?php if($errors->has('schedule_id')): ?>
        <p class="card red-text" style="padding:10px"><strong>Bạn cần phải chọn lịch học</strong></p>
    <?php endif; ?>
    <?php if($errors->has('gen_id')): ?>
        <p class="card red-text" style="padding:10px"><strong>Bạn cần phải chọn khoá</strong></p>
    <?php endif; ?>
    <?php if($errors->has('course_id')): ?>
        <p class="card red-text" style="padding:10px"><strong>Bạn cần phải chọn môn</strong></p>
    <?php endif; ?>
    <div class="row">
        <form method="post" action="<?php echo e(url('manage/storeclass')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($class->id); ?>"/>
            <div class="row">
                <div class="input-field col s12">
                    <input id="name" name="name" type="text" value="<?php echo e($class->name); ?>" class="validate">
                    <label for="name">Tên lớp</label>
                </div>
                <div class="input-field col s12">
                    <input id="description" name="description" type="text" value="<?php echo e($class->description); ?>"
                           class="validate">
                    <label for="description">Mô tả</label>
                </div>
                <div class="input-field col s12">
                    <input id="target" name="target" type="text" value="<?php echo e($class->target); ?>"
                           class="validate">
                    <label for="target">Chỉ tiêu nộp tiền</label>
                </div>
                <div class="input-field col s12">
                    <input id="regis_target" name="regis_target" type="text" value="<?php echo e($class->regis_target); ?>"
                           class="validate">
                    <label for="regis_target">Chỉ tiêu đăng kí</label>
                </div>
                <div class="input-field col s12">
                    <input id="study_time" name="study_time" type="text"
                           value="<?php echo e($class->study_time); ?>">
                    <label for="duration">Giờ học </label>
                </div>

                <div class="input-field col s12">
                    <select name="schedule_id">
                        <option value="" disabled selected>Choose your option</option>
                        <?php foreach($schedules as $s): ?>
                            <?php if($s->id == $class->schedule_id): ?>
                                <option value="<?php echo e($s->id); ?>" selected><?php echo e($s->name); ?> <?php echo e($s->description); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?>: <?php echo e($s->description); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                    <label>Lịch học</label>
                </div>

                <div class="input-field col s12">
                    <select name="room_id">
                        <?php foreach($bases as $base): ?>
                            <optgroup label="<?php echo e($base->name); ?> (<?php echo e($base->address); ?>)">
                                <?php foreach($base->rooms as $room): ?>
                                    <?php if($room->id == $class->room_id): ?>
                                        <option value="<?php echo e($room->id); ?>" selected><?php echo e($base->name); ?>: <?php echo e($room->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($room->id); ?>"><?php echo e($base->name); ?>: <?php echo e($room->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </optgroup>
                        <?php endforeach; ?>
                    </select>
                    <label>Phòng học</label>
                </div>
                <div class="input-field col s12 m6">
                    <select class="icons" name="course_id" id="course_id">
                        <option value="" disabled selected>Choose your option</option>
                        <?php foreach($courses as $course): ?>
                            <option value="<?php echo e($course->id); ?>"
                                    <?php echo e(($class->course_id == $course->id)?"selected":""); ?> data-icon="<?php echo e($course->icon_url); ?>"
                                    class="left circle"><?php echo e($course->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label>Môn học </label>
                </div>
                <div class="input-field col s12 m6">
                    <select class="icons" name="gen_id" id="gen_id">
                        <option value="" disabled selected>Choose your option</option>
                        <?php foreach($gens as $gen): ?>
                            <option value="<?php echo e($gen->id); ?>"
                                    <?php echo e(($class->gen_id == $gen->id)?"selected":""); ?>  class="left circle"><?php echo e($gen->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label>Khoá học </label>
                </div>

                <div class="input-field col s12 m6">
                    <select name="teacher_id" id="teacher_id">
                        <option value="" disabled selected>Choose your option</option>
                        <?php foreach($staffs as $staff): ?>
                            <option value="<?php echo e($staff->id); ?>"
                                    <?php echo e(($staff->id == $class->teacher_id)?"selected":""); ?>

                                    class="left circle"><?php echo e($staff->name); ?>(<?php echo e($staff->email); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label>Giảng viên </label>
                </div>
                <div class="input-field col s12 m6">
                    <select name="teaching_assistant_id" id="teaching_assistant_id">
                        <option value="" disabled selected>Choose your option</option>
                        <?php foreach($staffs as $staff): ?>
                            <option value="<?php echo e($staff->id); ?>"
                                    <?php echo e(($staff->id == $class->teaching_assistant_id)?"selected":""); ?>

                                    class="left circle"><?php echo e($staff->name); ?>(<?php echo e($staff->email); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label>Trợ giảng </label>
                </div>
                <div class="col s12" style="padding-bottom: 20px">
                    <label>Trạng thái tuyển sinh</label>
                    <!-- Switch -->
                    <div class="switch">
                        <label>
                            Đóng
                            <input name="status" type="checkbox" <?php echo e(($class->status==1)?"checked":""); ?>>
                            <span class="lever"></span>
                            Mở
                        </label>
                    </div>
                </div>

                <div class="col s12">
                    <label for="datestart">Ngày khai giảng</label>
                    <input type="text" name="datestart" id="datestart"
                           value="<?php echo e($class->datestart); ?>"
                           class="datepicker-new validate <?php echo e($errors->has('dob')?'invalid':''); ?>"/>
                </div>

                <div class="col s12" style="padding-top:20px">
                    <input type="submit" class="waves-effect waves-light btn" value="submit" name="submit"
                           id="submit"/>
                </div>


            </div>
        </form>

    </div>
    <div class="row">
        <?php if($class->id): ?>
            <?php if($class->schedule): ?>
                <a class="btn" href="<?php echo e(url("manage/set_class_lesson_time?class_id=".$class->id)); ?>">
                    tự động thêm thời gian cho buổi học
                </a>
            <?php else: ?>
                <div class="card red-text" style="padding: 10px"><p>Bạn chưa set lịch học nên không thể thêm lịch tự động</p></div>

            <?php endif; ?>
        <?php endif; ?>
        <h3 class="header">Buổi học của lớp <?php echo e($class->name); ?></h3>
        <?php /*<button onclick="refresh_lesson('<?php echo e($class->id); ?>')" class="waves-effect waves-light btn">Cập nhật buổi</button>*/ ?>
        <div class="col s12" id="class-lesson-container">

        </div>
    </div>
    <script>
        function save(lesson_id) {
            var class_id = '<?php echo e($class->id); ?>';
            $.post(
                "<?php echo e(url('manage/saveclasslessontime')); ?>",
                {
                    _token: '<?php echo e(csrf_token()); ?>',
                    'class_id': class_id,
                    'lesson_id': lesson_id,
                    time: $('#class-lesson-time' + lesson_id).val()
                },
                function (data, status) {
                    console.log(data);
                    $('#message' + lesson_id).html(data);
                }
            );
        }
        function refresh_lesson(class_id) {
            $('#class-lesson-container').html('<h3>Loading...</h3>');
            $.post(
                "<?php echo e(url('manage/refreshclasslesson')); ?>",
                {
                    _token: '<?php echo e(csrf_token()); ?>',
                    'class_id': class_id
                },
                function (data, status) {
                    console.log(data);
                    $('#class-lesson-container').html(data);
                }
            );
        }
        $(document).ready(function () {
            refresh_lesson(<?php echo e($class->id); ?>);

            $('.datepicker-new').datepicker();

            $(document).ready(function () {
                $('select').material_select();
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>