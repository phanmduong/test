<?php $__env->startSection('title',"Access denied"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col s12" style="text-align: center">
                <h4>Thật xin lỗi!</h4>
                <h5> Bạn không thể truy cập vào trang này</h5>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>