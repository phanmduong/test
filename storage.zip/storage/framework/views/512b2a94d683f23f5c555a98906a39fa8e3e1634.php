<?php $__env->startSection('title','Điểm danh'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="input-field col s12">
            <select id="gen-select">
                <?php foreach($gens as $gen): ?>
                    <option value="<?php echo e(url('manage/attendance?gen_id='.$gen->id)); ?>"
                            <?php echo e($gen->id == $current_gen->id?"selected":""); ?>>Khoá <?php echo e($gen->name); ?></option>
                <?php endforeach; ?>
            </select>
            <label>Khoá</label>
        </div>
    </div>
    <div class="row">
        <h3 class="header">Điểm danh</h3>
        <a href="<?php echo e(url('manage/scanqrcode')); ?>" class="waves-effect waves-light btn">Scan QR code</a>
        <?php /*<p>Khóa hiện tại: <?php echo e($current_gen->name); ?></p>*/ ?>
        <ul class="collapsible" data-collapsible="accordion">
            <?php foreach($classes as $class): ?>
                <?php /*<tr>*/ ?>
                <?php /*<td><a href="<?php echo e(url('manage/attendancelist/'.$class->id)); ?>"><?php echo e($class->name); ?></a></td>*/ ?>
                <?php /*<td><?php echo e($class->study_time); ?></td>*/ ?>
                <?php /*<td><?php echo e($class->teach->name); ?></td>*/ ?>
                <?php /*<td><?php echo e($class->assist->name); ?></td>*/ ?>
                <?php /*</tr>*/ ?>
                <li>
                    <div class="collapsible-header">
                        <img style="width: 37px;height:37px;margin-top:12px;margin-right:12px"
                             src="<?php echo e($class->course->icon_url); ?>" class="circle"/>
                        <span style="position: relative;bottom:15px">Lớp <strong><?php echo e($class->name); ?></strong>
                            <?php echo e($class->study_time); ?></span>
                    </div>
                    <div class="collapsible-body">
                        <?php if($class->activated == 1): ?>
                            <ul class="collection with-header">
                                <?php foreach($class->course->lessons->sortBy('order') as $lesson): ?>
                                    <li class="collection-item">
                                        <?php if($lesson->classLessons->where('class_id',$class->id)->count()>0): ?>
                                            <div>
                                            </div>
                                            <a href="<?php echo e(url('manage/attendancelist/'.$lesson->classLessons->where('class_id',$class->id)->first()->id)); ?>">Buổi <?php echo e($lesson->order); ?>

                                                : <?php echo e($lesson->name); ?></a>

                                            <?php if($lesson->classLessons->where('class_id',$class->id)->reduce(function($carry,$classLesson){
                                                    return $carry + $classLesson->attendances()->count();
                                                },0) >0): ?>
                                                <div>
                                                    <?php echo e($lesson->classLessons->where('class_id',$class->id)->reduce(function($carry,$classLesson){
                                                        return $carry + $classLesson->attendances()->where('status',1)->count();
                                                    },0)); ?>

                                                    /<?php echo e($lesson->classLessons->where('class_id',$class->id)->reduce(function($carry,$classLesson){
                                                    return $carry + $classLesson->attendances()->count();
                                                },0)); ?>

                                                </div>
                                                <div class="progress">
                                                    <div class="determinate" style="width: <?php echo e($lesson->classLessons->where('class_id',$class->id)->reduce(function($carry,$classLesson){
                                                    return $carry + $classLesson->attendances()->where('status',1)->count();
                                                },0)*100/$lesson->classLessons->where('class_id',$class->id)->reduce(function($carry,$classLesson){
                                                    return $carry + $classLesson->attendances()->count();
                                                },0)); ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            Không có lớp nào
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>

                            Chưa kích hoạt
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>


    </div>
    <script>
        $(document).ready(function () {
            $('.collapsible').collapsible({
                accordion: false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
            });
            $(document).ready(function () {
                $('select').material_select();
                $("#gen-select").change(function () {
                    if ($(this).val() != '') {
                        window.location.href = $(this).val();
                    }
                });
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>