<?php $__env->startSection('title','Danh sách lớp học'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="header">
        Lớp
    </h3>
    <div class="row">
        <form action="<?php echo e(url('manage/classes')); ?>">
            <input value='<?php echo e($search); ?>' placeholder="Tên lớp" type="text" name="search">
            <input class="btn" type="submit">
        </form>
        <p>Tổng số môn: <strong><?php echo e($total); ?></strong></p>

        <?php if($user->role == 2): ?>
            <p><a href="<?php echo e(url('manage/addclass')); ?>" class="waves-effect waves-light btn red lighten-1"><i
                            class="tiny-icons left fa fa-plus"></i>Thêm lớp mới</a></p>
        <?php endif; ?>
        <p></p>
        <table class="responsive-table striped">
            <thead>
            <tr>
                <th>Tên</th>
                <th>Ngày khai giảng</th>
                <th>Giờ</th>
                <th>Khoá</th>
                <th>Môn</th>
                <th>Giảng viên</th>
                <th>Trợ giảng</th>
                <th>Trạng thái tuyển sinh</th>
                <th style="padding-right:10px">Xoá</th>
                <?php if($user->role == 2): ?>
                    <th style="padding-right:10px">Duplicate</th>
                <?php endif; ?>
            </tr>
            </thead>

            <tbody>
            <?php foreach($classes as $class): ?>
                <tr>
                    <td><a href="<?php echo e(url('manage/editclass/'.$class->id)); ?>"><?php echo e($class->name); ?></a></td>
                    <td><?php echo e(format_date($class->datestart)); ?></td>
                    <td><?php echo e($class->study_time); ?></td>
                    <td><a href="<?php echo e(url('manage/editgen/'.$class->gen_id)); ?>"><?php echo e($class->gen->name); ?></a></td>
                    <td><a href="<?php echo e(url('manage/editcourse/'.$class->course_id)); ?>"><?php echo e($class->course->name); ?></a></td>
                    <td>
                        <?php if($class->teach): ?>
                            <?php echo e($class->teach['name']); ?>

                        <?php else: ?>
                            Chưa bổ nhiệm
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($class->assist): ?>
                            <?php echo e($class->assist['name']); ?>

                        <?php else: ?>
                            Chưa bổ nhiệm
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="switch">
                            <label>
                                <input name="status" id="class_status" onclick="change_status(<?php echo e($class->id); ?>);"
                                       type="checkbox" <?php echo e(($class->status==1)?"checked":""); ?> />
                                <span class="lever"></span>
                            </label>
                        </div>

                    </td>
                    <td>
                        <?php if($class->registers->count()>0): ?>
                            Đã có <strong><?php echo e($class->registers->count()); ?></strong> học viên
                        <?php else: ?>
                            <a onclick="return confirm('Bạn chắc chắn xoá lớp này? ');"
                               href="<?php echo e(url('manage/deleteclass/'.$class->id)); ?>"><i
                                        class="small material-icons">delete</i>
                            </a>
                        <?php endif; ?>

                    </td>
                    <?php if($user->role == 2): ?>
                        <td class="center">
                            <a href="<?php echo e(url('manage/duplicateclass/'.$class->id)); ?>"><i
                                        class="small material-icons">content_copy</i></a>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <ul class="pagination">
            <?php if($current_page != 1): ?>
                <li><a class="waves-effect" href="<?php echo e(url('manage/classes/'.($current_page-1))."?search=".$search); ?>"><i
                                class="material-icons">chevron_left</i></a></li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
            <?php endif; ?>
            <?php for($i=1;$i<=$num_pages;$i++): ?>
                <?php if($current_page == $i): ?>
                    <li class="active"><a href="#!"><?php echo e($i); ?></a></li>
                <?php else: ?>
                    <li><a class="waves-effect" href="<?php echo e(url('manage/classes/'.$i)."?search=".$search); ?>"><?php echo e($i); ?></a></li>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if($current_page != $num_pages): ?>
                <li><a class="waves-effect" href="<?php echo e(url('manage/classes/'.($current_page+1))."?search=".$search); ?>"><i
                                class="material-icons">chevron_right</i></a>
                </li>
            <?php else: ?>
                <li class="disabled"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
            <?php endif; ?>
        </ul>
    </div>

    <script>
        function change_status(id) {
            $.post("<?php echo e(url('manage/changeclassstatus')); ?>",
                {
                    "class_id": id,
                    '_token': '<?php echo e(csrf_token()); ?>'
                },
                function (data, status) {
                    console.log(status);
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>